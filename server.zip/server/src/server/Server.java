package server;

import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Server {

    public static void main(String[] args) {
        try {
            ServerSocket ss = new ServerSocket(1999);
            
            Socket s = ss.accept();
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            while (true) {
                System.out.println(dis.readUTF());
                //dos.writeUTF(" I would compete in it now");
                Scanner scanner = new Scanner(System.in);
                String message = scanner.nextLine();
                dos.writeUTF(message);
            }
        } catch (IOException ie) {
            ie.printStackTrace();
        }
    }
}
